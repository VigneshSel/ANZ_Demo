package StepDefinition;



import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
//import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class BorrowEstimator {
	
	WebDriver driver;
	String Dri_Loc;
	String ANZ_URL;
	
	@FindBy(xpath="//label[contains(text(),'Joint')]//following::input[@id='application_type_joint']")
	public static WebElement ApplicationType;

	@FindBy(xpath="//div[@class='borrow__question__answer borrow__question__answer--select']")
	public static WebElement Dependents;
	
	@FindBy(xpath="//label[contains(text(),'Home to live in')]")
	public static WebElement LivingType;
	
	@FindBy(xpath="//h3[contains(text(),'Your earnings')]/following::div/label[contains(text(),'Your annual income (before tax)')]/following::input[1]")
	public static WebElement Annualincome;
	//h3[contains(text(),'Your earnings')]/following::div/label[contains(text(),'Your annual income (before tax)')]/following::input[1]
	

@FindBy(xpath="//label[text()='Your other income']/following::div[1]/child::input")
public static WebElement FirstOtherincome;

@FindBy(id="expenses")
public static WebElement LivingExpense;

@FindBy(id="homeloans")
public static WebElement Homeloan;

@FindBy(id="otherloans")
public static WebElement Otherloan;

@FindBy(xpath="//label[@id='q3q4']/following::div[1]/child::input")
public static WebElement Othercommitments;

@FindBy(id="credit")
public static WebElement credtcardlimit;

@FindBy(id="btnBorrowCalculater")
public static WebElement BorrowcalculatorButton;

@FindBy(id="borrowResultTextAmount")
public static WebElement BorrowEstimate;

@FindBy(className="borrow__error__text")
public static WebElement Borrowinfomessage;

@FindBy(xpath="//label[@id='q2q3']/following-sibling::div[1]/child::input[1]")
public static WebElement Secondincome;

@FindBy(xpath="//label[@id='q2q4']/following-sibling::div[1]/child::input[1]")
public static WebElement Secondotherincome;

@FindBy(className="start-over")
public static WebElement StartOver;

	@Given("the user enters the url")
	public void user_entering() {
		
		FileReader reader=null;
		try {
			reader=new FileReader("config.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
				Properties properties=new Properties();
				try {
					properties.load(reader);
				} catch (IOException e) {
					e.printStackTrace();
				}	
				
				Dri_Loc=properties.getProperty("DriverLocation");
				ANZ_URL=properties.getProperty("Appurl");
				
		
		System.setProperty("webdriver.chrome.driver", Dri_Loc);
		if(driver==null)
		{
		driver = new ChromeDriver();
		}
		driver.get(ANZ_URL);
		driver.manage().window().maximize();
		
	}
	
	@Then("the user enters the Application Type")
	public void user_enters_the_Application_Type() {
		
	
		

	}
	
	@Given("the user enters the No of Dependents {string}")
	public void noofdependents (String NoOfDependents) {
		WebElement Dropdown=Dependents;
		Select select=new Select(Dropdown);
		select.selectByVisibleText(NoOfDependents);
	}
	
	@Then("the user enters the Property to Buy")
	public void user_enters_the_PropertyToBuy() {
		LivingType.click();
			

	}
	  
	
	@Given("the user enters the AnnualIncome {string}")
	public void userincome(String AnnualIncome) throws InterruptedException
	
	{  Thread.sleep(5000);
	
	
		Annualincome.sendKeys(AnnualIncome);
	}
	
	@Given("the user enters the OtherIncome {string}")
	public void other_income(String other_income) {	    
		  FirstOtherincome.sendKeys(other_income.toString());
	}
	
	@When("the user enters the MonthlyExpenses {string}")
	public void living_expenses(String expenses) {
		  LivingExpense.sendKeys(expenses);
	}
	
	
	@When("the user enters the CurrentLoanAmount {string}")
	public void current_home_repayment(String homeloans)  {
		  Homeloan.sendKeys(homeloans);
	}
	
	@When("the user enters the OtherLoan {string}")
	public void other_loan_repayments(String otherloans) {
		  Otherloan.sendKeys(otherloans);
	}
	
	@When("the user enters the OthersExpenses {string}")
	public void other_commitments(String other_commit) {
		  Othercommitments.sendKeys(other_commit.toString());
	}
	
	@When("the user enters the TotalCredits {string}")
	public void total_credit_card_limits(String CC_limit) {
		  credtcardlimit.sendKeys(CC_limit.toString());
	}
	
	@When("the user clicks on the Button Work out how much I could borrow to Borrow")
	public void user_select_work_out_how_much_i_could_borrow_button() throws InterruptedException {
		driver.findElement(By.id("btnBorrowCalculater")).click();
		WebElement Fieldvalueamount=  BorrowEstimate;
		String Field_value= Fieldvalueamount.getText();
		while( !Fieldvalueamount.getText().equals(Field_value))
		{
			Field_value= Fieldvalueamount.getText();
		}
		
	}
	
	@Then("the user verifies if the Borrowing Estimate is displayed as mentioned")
	public void user_see_the_borrowing_estimate() {
		WebElement EstimateAmount=  BorrowEstimate;
		WebElement ErrorText=  Borrowinfomessage;
		if(EstimateAmount.isDisplayed()) {
			System.out.println(EstimateAmount.getText());
		}
		else if (ErrorText.isDisplayed()) {
			System.out.println(ErrorText.getText());

		}
			

	}
	
	@When("the user clicks on StartOver Button")
	public void user_click_on_startover_button() {
		StartOver.click();
	}
	@Then("User should see the Details cleared estimate form")
	public void user_should_see_the_details_cleared_estimate_form() {
		System.out.println("form cleared");
		Boolean Startovericon=  StartOver.isDisplayed();
		Boolean Borrowcalculatorbtn=  BorrowcalculatorButton.isDisplayed();
		if(Startovericon.equals(false)&&Borrowcalculatorbtn.equals(true))
			System.out.println("form successfully cleared");
			
		
	
	}
	

}
